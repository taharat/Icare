package com.example.mobileappdevelop.icare;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class EditActivity extends ActionBarActivity implements View.OnClickListener {
    private EditText etFirstName;
    private EditText etLastName;
    private EditText etGender;
    private EditText etDateOfBirth;
    private EditText etBloodGroup;
    private EditText etHeight;
    private EditText etWeight;
    private EditText etBmi;

    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String gender;
    private String bloodGroup;
    private String height;
    private String weight;
    private String bmi;

    private Button btnUpdateProfile;
    private Profile aProfile;
    private ProfileDBHandler dbHandler;
    private Intent intent;
    private static int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        initialize();
        Bundle b = getIntent().getExtras();
        aProfile = b.getParcelable("profile");
        setValue(aProfile);
        btnUpdateProfile.setOnClickListener(this);
    }
    private void initialize() {
        dbHandler = new ProfileDBHandler(EditActivity.this);

        etFirstName = (EditText) findViewById(R.id.etFirstName);
        etLastName = (EditText) findViewById(R.id.etLastName);
        etGender = (EditText) findViewById(R.id.etGender);
        etDateOfBirth = (EditText) findViewById(R.id.etDateOfBirth);
        etBloodGroup = (EditText) findViewById(R.id.etBloodGroup);
        etHeight = (EditText) findViewById(R.id.etHeight);
        etWeight = (EditText) findViewById(R.id.etWeight);
        etBmi = (EditText) findViewById(R.id.etBMI);

        btnUpdateProfile = (Button) findViewById(R.id.btnUpdate);
    }
    private void setValue(Profile profile) {
        id = profile.getProfileID();
        showMessage(String.valueOf(id));
        etFirstName.setText(profile.getFirstName());
        showMessage(profile.getFirstName());
        etLastName.setText(profile.getLastName());
        etGender.setText(profile.getGender());
        etDateOfBirth.setText(profile.getGender());
        etBloodGroup.setText(profile.getBloodGroup());
        etHeight.setText(profile.getHeight());
        etWeight.setText(profile.getWeight());
        etBmi.setText(profile.getBmi());

    }

    private void getValue() {
        Profile upProfile = new Profile();
        firstName = etFirstName.getText().toString();
        lastName = etLastName.getText().toString();
        dateOfBirth = etDateOfBirth.getText().toString();
        gender = etGender.getText().toString();
        bloodGroup = etGender.getText().toString();
        height = etHeight.getText().toString();
        weight = etWeight.getText().toString();
        bmi = etBmi.getText().toString();

        upProfile.setProfileID(id);
        upProfile.setFirstName(firstName);
        upProfile.setLastName(lastName);
        upProfile.setGender(gender);
        upProfile.setDateOfBirth(dateOfBirth);
        upProfile.setHeight(height);
        upProfile.setWeight(weight);
        upProfile.setBloodGroup(bloodGroup);
        upProfile.setBmi(bmi);

        dbHandler.updateProfile(upProfile);
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_edit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnUpdate:
                getValue();
                showMessage("Updated Successfully");
                finish();
                break;
            default:
                break;
        }
    }
    private void showMessage(String str){
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }
}
