package com.example.mobileappdevelop.icare;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mobile App Develop on 8-6-15.
 */
public class ProfileDBHandler {
    // All Static variables
    public static final String PROFILE = CommonDBAdapter.PROFILE_TABLE_NAME;
    public static final String ROW_ID = CommonDBAdapter.ID;
    public static final String FIRST_NAME = CommonDBAdapter.PROFILE_FIRST_NAME;
    public static final String LAST_NAME = CommonDBAdapter.PROFILE_LAST_NAME;
    public static final String GENDER = CommonDBAdapter.PROFILE_GENDER;
    public static final String DATE_OF_BIRTH = CommonDBAdapter.PROFILE_DATE_OF_BIRTH;
    public static final String BLOOD_GROUP = CommonDBAdapter.PROFILE_BLOOD_GROUP;
    public static final String HEIGHT = CommonDBAdapter.PROFILE_HEIGHT;
    public static final String WEIGHT = CommonDBAdapter.PROFILE_WEIGHT;
    public static final String BMI = CommonDBAdapter.PROFILE_BMI;

    public static final String[] COLUMNS = new String[]{
            ROW_ID,
            FIRST_NAME,
            LAST_NAME,
            GENDER,
            DATE_OF_BIRTH,
            BLOOD_GROUP,
            HEIGHT,
            WEIGHT,
            BMI
    };


    private CommonDBAdapter mDbHelper;
    private Context mContext;
    private SQLiteDatabase db;
    public ProfileDBHandler(Context context) {
        this.mContext = context;
        mDbHelper = new CommonDBAdapter(context);
    }


    void addProfile(Profile aProfile) {

        SQLiteDatabase db = mDbHelper.open();

        ContentValues values = new ContentValues();
        values.put(FIRST_NAME, aProfile.getFirstName());
        values.put(LAST_NAME, aProfile.getLastName());
        values.put(GENDER, aProfile.getGender()== null ? "" : aProfile.getGender());
        values.put(DATE_OF_BIRTH, aProfile.getDateOfBirth()== null ? "" : aProfile.getDateOfBirth());
        values.put(BLOOD_GROUP, aProfile.getBloodGroup()== null ? "": aProfile.getBloodGroup());
        values.put(HEIGHT, aProfile.getHeight()== null ? "":  aProfile.getHeight());
        values.put(WEIGHT, aProfile.getWeight()== null ? "":  aProfile.getWeight());
        values.put(BMI, aProfile.getBmi()== null ? "": aProfile.getBmi());

        // Inserting Row
        long result = db.insert(PROFILE, null, values);
//        Log.d("=========== Name ==========", "=====================" + result);

        db.close(); // Closing database connection
    }

    public Cursor getAllCursorProfile(){
        open();
        Cursor cursor;

        cursor = db.query(PROFILE, COLUMNS, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        db.close();
        return cursor;
    }

    public List<Profile> getAllProfile() {
        List<Profile> profileList = new ArrayList<Profile>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + PROFILE;

        open();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Profile aProfile = new Profile();
                aProfile.setProfileID(cursor.getInt(0));
                aProfile.setFirstName(cursor.getString(1));
                aProfile.setLastName(cursor.getString(2));
                aProfile.setGender(cursor.getString(3));
                aProfile.setDateOfBirth(cursor.getString(4));
                aProfile.setBloodGroup(cursor.getString(5));
                aProfile.setHeight(cursor.getString(6));
                aProfile.setWeight(cursor.getString(7));
                aProfile.setBmi(cursor.getString(8));
                profileList.add(aProfile);
            } while (cursor.moveToNext());
        }
        db.close();
        return profileList;
    }

    public Profile getProfileByID(int id) {
        String selectQuery = "SELECT  * FROM " + PROFILE + " where _id = " + id;

        open();
        Cursor cursor = db.rawQuery(selectQuery, null);
        Profile aProfile = new Profile();

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            aProfile.setProfileID(cursor.getInt(0));
            aProfile.setFirstName(cursor.getString(1));
            aProfile.setLastName(cursor.getString(2));
            aProfile.setGender(cursor.getString(3));
            aProfile.setDateOfBirth(cursor.getString(4));
            aProfile.setBloodGroup(cursor.getString(5));
            aProfile.setHeight(cursor.getString(6));
            aProfile.setWeight(cursor.getString(7));
            aProfile.setBmi(cursor.getString(8));
        }
        db.close();
        return aProfile;
    }


    public int updateProfile(Profile aProfile) {
        SQLiteDatabase db = mDbHelper.open();

        ContentValues values = new ContentValues();

        values.put(ROW_ID, aProfile.getProfileID());
        values.put(FIRST_NAME, aProfile.getFirstName());
        values.put(LAST_NAME, aProfile.getLastName());
        values.put(GENDER, aProfile.getGender());
        values.put(DATE_OF_BIRTH, aProfile.getDateOfBirth());
        values.put(BLOOD_GROUP, aProfile.getBloodGroup());
        values.put(HEIGHT, aProfile.getHeight());
        values.put(WEIGHT, aProfile.getWeight());
        values.put(BMI, aProfile.getBmi());


        return db.update(PROFILE, values, ROW_ID + " = ?",
                new String[]{String.valueOf(aProfile.getProfileID())});
    }

    void deleteProfile(int id){
        SQLiteDatabase db = mDbHelper.open();
        db.delete(PROFILE, ROW_ID +"= ?", new String[] {String.valueOf(id)});
        db.close();
    }
    public void open() throws SQLException {
        db = mDbHelper.open();
    }
}
