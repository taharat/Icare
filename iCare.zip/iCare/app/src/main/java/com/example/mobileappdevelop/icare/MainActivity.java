package com.example.mobileappdevelop.icare;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;


public class MainActivity extends ActionBarActivity {
    private Intent intent;
    private ListView lvProfile;
    private ProfileDBHandler dbHandler;
    private List<Profile> profileList;
    private CustomProfileAdapter adapter;
    private Profile profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }
    private void initialize() {
        lvProfile = (ListView) findViewById(R.id.lvProfile);
        dbHandler = new ProfileDBHandler(MainActivity.this);
        updateDatabase();

        lvProfile.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                profile = (Profile) parent.getItemAtPosition(position);
                intent = new Intent(MainActivity.this, DetailProfileActivity.class);
                intent.putExtra("profile", profile);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch(id){
            case R.id.new_profile:
                intent = new Intent(MainActivity.this, NewProfileActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_delete:
                intent = new Intent(MainActivity.this, DeleteActivity.class);
                startActivity(intent);
                return true;
            case R.id.alarm:
                intent = new Intent(MainActivity.this, ReminderActivity.class);
                startActivity(intent);
                return true;
            case R.id.map:
                intent = new Intent(MainActivity.this, GMap.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }


    }
    private void updateDatabase(){
        profileList = dbHandler.getAllProfile();
        if (!profileList.isEmpty()){
            adapter = new CustomProfileAdapter(this, profileList);
            lvProfile.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDatabase();
    }
}
