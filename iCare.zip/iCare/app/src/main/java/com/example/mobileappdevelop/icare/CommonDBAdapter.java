package com.example.mobileappdevelop.icare;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Nadia Akter on 6/10/2015.
 */
public class CommonDBAdapter {
    public static final String DATABASE_NAME = "iCareDB";
    public static final int DATABASE_VERSION = 1;

    /*========================== Profile Table ==========================*/

    public static final String PROFILE_TABLE_NAME = "tbl_profile";

    public static final String ID = "_id";
    public static final String PROFILE_FIRST_NAME = "first_name";
    public static final String PROFILE_LAST_NAME = "last_name";
    public static final String PROFILE_GENDER = "gender";
    public static final String PROFILE_DATE_OF_BIRTH = "date_of_birth";
    public static final String PROFILE_BLOOD_GROUP = "blood_group";
    public static final String PROFILE_HEIGHT = "height";
    public static final String PROFILE_WEIGHT = "weight";
    public static final String PROFILE_BMI= "bmi";


    String SQL_CREATE_PROFILE_TABLE = "CREATE TABLE " + PROFILE_TABLE_NAME + " ("
            + ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + PROFILE_FIRST_NAME + " TEXT," + PROFILE_LAST_NAME + " TEXT, "
            + PROFILE_GENDER + " TEXT," + PROFILE_DATE_OF_BIRTH + " TEXT, "
            + PROFILE_BLOOD_GROUP + " TEXT, " + PROFILE_HEIGHT+ " TEXT, "
            + PROFILE_WEIGHT + " TEXT," + PROFILE_BMI + " TEXT)";



    private final Context context;
    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;

    public CommonDBAdapter(Context context) {
        this.context = context;
        this.DBHelper = new DatabaseHelper(this.context);
    }

    public class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_PROFILE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + PROFILE_TABLE_NAME);
            // Create tables again
            onCreate(db);
        }
    }

    public SQLiteDatabase open(){
        this.db = this.DBHelper.getWritableDatabase();
        return db;
    }

    public void close(){
        this.DBHelper.close();
    }
}