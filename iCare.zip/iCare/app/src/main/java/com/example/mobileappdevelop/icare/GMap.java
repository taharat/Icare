package com.example.mobileappdevelop.icare;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class GMap extends FragmentActivity implements LocationListener{

    private GoogleMap mMap; // Might be null if Google Play services APK is not available.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gmap);
        setUpMapIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #setUpMap()} once when {@link #mMap} is not null.
     * <p/>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p/>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not
     * have been completely destroyed during this process (it is likely that it would only be
     * stopped or paused), {@link #onCreate(Bundle)} may not be called again so we should call this
     * method in {@link #onResume()} to guarantee that it will be called.
     */
    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     * This is where we can add markers or lines, add listeners or move the camera. In this case, we
     * just add a marker near Africa.
     * <p/>
     * This should only be called once and when we are sure that {@link #mMap} is not null.
     */
    private void setUpMap() {
       // mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Marker"));

        Toast.makeText(this,"Fire Service Information",Toast.LENGTH_LONG).show();

        mMap.addMarker(new MarkerOptions().position(new LatLng(23.789515, 90.419716)).title("Shahabuddin Medical College Hospital").snippet("House no 12\n" +
                "Rd No 113/A\n" +
                "Dhaka 1212")).showInfoWindow();


        mMap.addMarker(new MarkerOptions().position(new LatLng(23.791487,90.420066)).title("Z H Sikder Women's Medical College & Hospital").snippet("Gulshan\n" +
                "Dhaka")).showInfoWindow();

        mMap.addMarker(new MarkerOptions().position(new LatLng(23.784501, 90.42553)).title("Badda General Hospital").snippet("Uttar Badda\n" +
                "Dhaka")).showInfoWindow();
        mMap.addMarker(new MarkerOptions().position(new LatLng(23.773303, 90.399799)).title("Dhaka Metropolitan Hospital").snippet("Mohakhali\n" +
                "Dhaka")).showInfoWindow();

        mMap.addMarker(new MarkerOptions().position(new LatLng(23.741821, 90.38306)).title("Labaid Specialized Hospital").snippet("Kemal Ataturk Avenue\n" +
                "Dhaka 1212\n"+ "01713-091940")).showInfoWindow();
        mMap.addMarker(new MarkerOptions().position(new LatLng(23.764540,90.400490)).snippet("Shaheed Tajuddin Ahmed Ave\n" +
                "Dhaka 1208" + "\n" + "01730-002226")).showInfoWindow();
        mMap.addMarker(new MarkerOptions().position(new LatLng(23.769161, 90.37101)).title("Shaheed Suhrawardy Medical College and Hospital").snippet("Sher- E- Bangla Nagar\n" +
                "Dhaka 1207")).showInfoWindow();
        mMap.addMarker(new MarkerOptions().position(new LatLng(23.773629, 90.361497)).title("Dhaka Central International Medical College & Hospital").snippet("2/1\n" +
                "Ring Rd\n" +
                "Dhaka 1207"+"\n"+"02-9124396")).showInfoWindow();
//        mMap.addMarker(new MarkerOptions().position(new LatLng(23.721810, 90.390226)).title("Lalbagh Fire station").snippet("Orphanages Rd\n" +
//                "Dhaka 1000"+"\n"+"02-8619981")).showInfoWindow();
//        mMap.addMarker(new MarkerOptions().position(new LatLng(23.464250, 91.171889)).title("Bangladesh Fire Service and Civil Defense").snippet("38-46\n" +
//                "Kazi Allaudin Rd\n" +
//                "Dhaka 1000"+"\n"+"02-9555555")).showInfoWindow();
//        mMap.addMarker(new MarkerOptions().position(new LatLng(23.697767, 90.345773)).title("Keranigonj Fire Station").snippet("Konakhola Upozila Parishad Road\n" +
//                "Keraniganj"+"\n"+"01730-002247")).showInfoWindow();
//

        //mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(23.8085163, 90.3704918)));


        mMap.animateCamera(CameraUpdateFactory.zoomTo(12));
        mMap.setMyLocationEnabled(true);
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        String bestProvider = locationManager.getBestProvider(criteria, true);
        Location location = locationManager.getLastKnownLocation(bestProvider);
        if (location != null) {
            onLocationChanged(location);
        }
        locationManager.requestLocationUpdates(bestProvider, 20000, 0, this);

//        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
//            @Override
//            public boolean onMarkerClick(Marker marker) {
//                Toast.makeText(getApplicationContext(),"Yaa its work",Toast.LENGTH_LONG).show();
//                return false;
//            }
//        });

    }

    @Override
    public void onLocationChanged(Location location) {

        TextView locationTv = (TextView) findViewById(R.id.latlongLocation);
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        LatLng latLng = new LatLng(latitude, longitude);
        mMap.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));
        locationTv.setText("Latitude:" + latitude + ", Longitude:" + longitude);




    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

}

