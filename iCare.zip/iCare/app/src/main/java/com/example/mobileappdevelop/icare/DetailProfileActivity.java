package com.example.mobileappdevelop.icare;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;


public class DetailProfileActivity extends ActionBarActivity {
    private TextView tvFirstName;
    private TextView tvLastName;
    private TextView tvGender;
    private TextView tvDateOfBirth;
    private TextView tvBloodGroup;
    private TextView tvHeight;
    private TextView tvWeight;
    private TextView tvBMI;

    private String id;
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String gender;
    private String bloodGroup;
    private String height;
    private String weight;
    private String bmi;

    private Intent intent;
    private Profile profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_profile);
        initialize();
    }

    private void initialize() {
        tvFirstName = (TextView) findViewById(R.id.tvFirstName);
        tvLastName = (TextView) findViewById(R.id.tvLastName);
        tvGender = (TextView) findViewById(R.id.tvGender);
        tvDateOfBirth = (TextView) findViewById(R.id.tvDateOfBirth);
        tvBloodGroup = (TextView) findViewById(R.id.tvBloodGroup);
        tvHeight = (TextView) findViewById(R.id.tvHeight);
        tvWeight = (TextView) findViewById(R.id.tvWeight);
        tvBMI = (TextView) findViewById(R.id.tvBMI);

        Bundle b = getIntent().getExtras();
        profile = b.getParcelable("profile");
        setValue(profile);
    }
    private void setValue(Profile aProfile) {
        id = String.valueOf(aProfile.getProfileID());
        firstName = aProfile.getFirstName();
        lastName = aProfile.getLastName();
        gender = aProfile.getGender();
        dateOfBirth = aProfile.getDateOfBirth();
        bloodGroup = aProfile.getBloodGroup();
        height = aProfile.getHeight();
        weight = aProfile.getWeight();
        bmi = aProfile.getBmi();

        tvFirstName.setText(firstName);
        tvLastName.setText(lastName);
        tvGender.setText(gender);
        tvDateOfBirth.setText(gender);
        tvBloodGroup.setText(bloodGroup);
        tvHeight.setText(height);
        tvWeight.setText(weight);
        tvBMI.setText(bmi);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_detail_profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()){
            case R.id.edit:
                intent = new Intent(DetailProfileActivity.this, EditActivity.class);
                intent.putExtra("profile", profile);
                startActivity(intent);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }
    private void showMessage(String str){
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }
}
