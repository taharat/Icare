package com.example.mobileappdevelop.icare;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;


public class DeleteActivity extends ActionBarActivity {

    private ListView lvEmployee;
    private CustomAdapterSelect adapter;
    private List<Profile> profileList;
    private ProfileDBHandler dbHandler;
    private String from;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        initialize();
    }

    private void initialize() {

        lvEmployee = (ListView) findViewById(R.id.lvProfile);
        dbHandler = new ProfileDBHandler(this);
        profileList = dbHandler.getAllProfile();
        adapter = new CustomAdapterSelect(this, profileList);
        lvEmployee.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_delete, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){

            case R.id.menu_delete:
                new AlertDialog.Builder(DeleteActivity.this)
                        .setTitle("Delete Log")
                        .setMessage("This log will be deleted")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                for (int i : CustomAdapterSelect.idList.keySet()) {
                                    int id = CustomAdapterSelect.idList.get(i);
                                    dbHandler.deleteProfile(id);
                                }
                                showMessage("Deleted Successfully");
                                CustomAdapterSelect.idList.clear();
                                CustomAdapterSelect.itemChecked.clear();
                                finish();
                            }
                        })
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //Do nothing
                            }
                        })
                        .show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        clear();
    }

    @Override
    protected void onResume() {
        super.onResume();
        clear();

    }

    private void clear(){
        CustomAdapterSelect.idList.clear();
        CustomAdapterSelect.itemChecked.clear();
    }
    private void showMessage(String msg){
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}
