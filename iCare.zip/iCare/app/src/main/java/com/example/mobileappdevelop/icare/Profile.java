package com.example.mobileappdevelop.icare;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Mobile App Develop on 8-6-15.
 */
public class Profile implements Parcelable {
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String gender;
    private String bloodGroup;
    private String height;
    private String weight;
    private String bmi;

    private int profileID;
    //private Integer id;

    public Profile(Parcel source) {

        //id = source.readInt();
        profileID = source.readInt();
        firstName = source.readString();
        lastName = source.readString();
        dateOfBirth = source.readString();
        gender = source.readString();
        bloodGroup = source.readString();
        height = source.readString();
        weight = source.readString();
        bmi = source.readString();
    }
    public Profile(){

    }

    public int getProfileID() {
        return profileID;
    }

    public void setProfileID(int profileID) {
        this.profileID = profileID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getBmi() {
        return bmi;
    }

    public void setBmi(String bmi) {
        this.bmi = bmi;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        //dest.writeInt(id);
        dest.writeInt(profileID);
        dest.writeString(firstName);
        dest.writeString(lastName);
        dest.writeString(dateOfBirth);
        dest.writeString(gender);
        dest.writeString(bloodGroup);
        dest.writeString(height);
        dest.writeString(weight);
        dest.writeString(bmi);
    }

    public static final Creator<Profile> CREATOR
            = new Parcelable.Creator<Profile>(){
        @Override
        public Profile createFromParcel(Parcel source) {
            return new Profile(source);
        }

        @Override
        public Profile[] newArray(int size) {
            return new Profile[size];
        }
    };
}
