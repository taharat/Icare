package com.example.mobileappdevelop.icare;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class NewProfileActivity extends ActionBarActivity implements View.OnClickListener {
    private EditText etFirstName;
    private EditText etLastName;
    private EditText etGender;
    private EditText etDateOfBirth;
    private EditText etBloodGroup;
    private EditText etHeight;
    private EditText etWeight;
    private EditText etBmi;

    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String gender;
    private String bloodGroup;
    private String height;
    private String weight;
    private String bmi;

    private Button btnSaveProfile;
    private Profile aProfile;
    private ProfileDBHandler dbHandler;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_profile);

        initialize();
        btnSaveProfile.setOnClickListener(this);

    }

    private void initialize() {
        aProfile = new Profile();
        dbHandler = new ProfileDBHandler(NewProfileActivity.this);

        etFirstName = (EditText) findViewById(R.id.etFirstName);
        etLastName = (EditText) findViewById( R.id.etLastName);
        etGender = (EditText) findViewById(R.id.etGender);
        etDateOfBirth = (EditText) findViewById(R.id.etDateOfBirth);
        etBloodGroup = (EditText) findViewById(R.id.etBloodGroup);
        etHeight = (EditText) findViewById(R.id.etHeight);
        etWeight = (EditText) findViewById(R.id.etWeight);
        etBmi = (EditText) findViewById(R.id.etBMI);

        btnSaveProfile = (Button) findViewById(R.id.btnSave);
    }

    private void getValue() {
        firstName = etFirstName.getText().toString();
        lastName = etLastName.getText().toString();
        gender = etGender.getText().toString();
        dateOfBirth = etDateOfBirth.getText().toString();
        bloodGroup = etBloodGroup.getText().toString();
        height = etHeight.getText().toString();
        weight = etWeight.getText().toString();
        bmi = etBmi.getText().toString();

        aProfile.setFirstName(firstName);
        aProfile.setLastName(lastName);
        aProfile.setGender(gender);
        aProfile.setDateOfBirth(dateOfBirth);
        aProfile.setHeight(height);
        aProfile.setWeight(weight);
        aProfile.setBloodGroup(bloodGroup);
        aProfile.setBmi(bmi);

        dbHandler.addProfile(aProfile);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_new_profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSave:
                getValue();

                showMessage("Saved Successfully");
                finish();
                break;
            default:
                break;
        }
    }
    private void showMessage(String str){
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }
}
